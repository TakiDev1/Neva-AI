# You do not need anything to be changed here, except one optional part.
# It removes the warning on the website that this won't work.
# Go to templates, and press on home.html, then delete all of line 23.
# Do not mess with anything else on home.html unless you know what you are doing,
# Don't mess with this main file, main.py, at all.

from flask import Flask, render_template, request
import requests
import os
import openai
import json


apiKey = os.environ['APIKEY']

app = Flask('app')

headers = {
  "Content-Type": "application/json"
}


openai.api_key = apiKey

model_engine = "text-davinci-003"



@app.route('/', methods=['GET','POST'])
def home():
  if request.method == "POST":
    question = request.form.get("question")
    completions = openai.Completion.create(
        engine=model_engine,
        prompt=question,
        max_tokens=3000,
        n=1,
        stop=None,
        temperature=0.5,
    )
    answer = completions.choices[0].text
    return render_template("home.html", question=question, answer=answer)
  else:
    return render_template("home.html", answer=None)


app.run(host='0.0.0.0', port=8080)